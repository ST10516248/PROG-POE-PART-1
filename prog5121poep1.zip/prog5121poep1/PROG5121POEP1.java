/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121poep1;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class PROG5121POEP1 {

   public static void main(String[]args){
            
        Scanner input = new Scanner(System.in);
        Login user = new Login();
        //registration
        System.out.print("Enter your username:");
        String username = input.nextLine();
        user.username = username;
        
        System.out.print("Enter your password:");
        String password = input.nextLine();
        user.password = password;
       
        System.out.print("Enter your phone number (+27....):");
        String phoneNumber = input.nextLine();
        user.phoneNumber = phoneNumber;
        
        System.out.println(user.registerUser());
        
        //Login
        System.out.print("Enter username to login:");
        String loginUsername = input.nextLine();
        
        System.out.print("Enter password to Login");
        String loginPassword = input.nextLine();
        
        //Checking if the login details and requirements are correct
        boolean loginSuccess = user.loginUser(loginUsername, loginPassword);
        
        System.out.println(user.returninStatus(loginSuccess));
    }
}
