/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121poep1;

/**
 *
 * @author Student
 */
public class Login {
    //Variables storing user details
    String username;
    String password;
    String phoneNumber;
    String firstName;
    String lastName;
    
    //Check username
    public boolean checkUserName() {
        return username.contains("_")&& username.length() <=5;
    }
    
//Checking the password complexity
    public boolean checkPasswordComplexity() {
        return password.length() >= 8 &&
                password.matches(".*[A-Z].*")&&
                password.matches(".*[0-9].*")&&
                password.matches(".*[^a-zA-z0-9].*");
    }
    //Checking the phone number
    public boolean checkCellPhoneNumber() {
        return phoneNumber.matches("^\\+27\\d{9}$");
    }
    //Registering users
    public String registerUser(){
        if (!checkUserName()){
            return "Username is incorrectly formatted; please ensure that your"
                    + "username contains an underscore and is not more than 5"
                    + "characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the"
                    + "password contains at least 8 characters, a capital letter,"
                    + "a number and a speacial character.";
        }
        if (!checkCellPhoneNumber()){
            return "Cellphone number incorrectly formatted or does not contain "
                    + "international code";
        }
        return "User registered successfully.";
    }
    
//Login check 
    public boolean loginUser(String enteredUsername, String enteredPassword){
        return enteredUsername.equals(username)&& enteredPassword.equals(password);
    }
    //Login message if login is succesful
    public String returninStatus(boolean loginSuccess){
        
        if (loginSuccess){
            return "Welcome" + firstName + "," + lastName + "it is good to have"
                    + "you again.";
        }else{
            return "username or password incorrect, please try again.";
        }
    }
}

    